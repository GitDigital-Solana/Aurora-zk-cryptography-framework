#!/bin/bash

# Create CLI demo
mkdir -p cli-demo/src/commands
cat > cli-demo/package.json << 'EOF'
{
  "name": "aurora-cli-demo",
  "type": "module",
  "scripts": {
    "start": "ts-node src/index.ts"
  },
  "dependencies": {
    "@solana/web3.js": "^1.95.0",
    "commander": "^12.0.0",
    "aurora-sdk": "file:../sdk/typescript"
  },
  "devDependencies": {
    "ts-node": "^10.9.2",
    "typescript": "^5.0.0"
  }
}
EOF
