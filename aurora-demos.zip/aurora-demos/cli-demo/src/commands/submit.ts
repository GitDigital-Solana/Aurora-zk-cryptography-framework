import { Connection, Keypair, sendAndConfirmTransaction } from '@solana/web3.js';
import { submitProofIx } from 'aurora-sdk';

export default async function submit(proofHex: string, data: string) {
  const proof = Buffer.from(proofHex, 'hex');
  const bytes = Buffer.from(data);
  const connection = new Connection('http://localhost:8899');
  const payer = Keypair.generate();
  const ix = await submitProofIx(payer.publicKey, proof, bytes);
  const tx = await sendAndConfirmTransaction(connection, ix, [payer]);
  console.log('Submitted TX:', tx);
}
