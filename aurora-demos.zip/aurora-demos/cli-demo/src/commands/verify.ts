import { verifyProof } from 'aurora-sdk';

export default function verify(proofHex: string, data: string) {
  const proof = Buffer.from(proofHex, 'hex');
  const bytes = Buffer.from(data);
  const valid = verifyProof(proof, bytes);
  console.log(valid ? 'VALID' : 'INVALID');
}
