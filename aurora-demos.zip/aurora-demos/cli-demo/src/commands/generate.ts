import { generateProof } from 'aurora-sdk';

export default function generate(data: string) {
  const bytes = Buffer.from(data);
  const proof = generateProof(bytes, Date.now());
  console.log(Buffer.from(proof).toString('hex'));
}
