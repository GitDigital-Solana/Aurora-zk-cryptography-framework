import { Connection, Keypair, sendAndConfirmTransaction } from '@solana/web3.js';
import { submitProofIx } from 'aurora-sdk';

export default async function replay() {
  const connection = new Connection('http://localhost:8899');
  const payer = Keypair.generate();
  const proof = Buffer.from([1, 2, 3]);
  const data = Buffer.from([4, 5, 6]);
  const ix = await submitProofIx(payer.publicKey, proof, data);
  const tx = await sendAndConfirmTransaction(connection, ix, [payer]);
  console.log('First TX:', tx);
  try {
    await connection.sendRawTransaction(Buffer.from(tx, 'base64'));
    console.log('Replay succeeded (unexpected)');
  } catch {
    console.log('Replay correctly rejected');
  }
}
