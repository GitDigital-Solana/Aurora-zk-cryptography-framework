import { Command } from 'commander';
import generate from './commands/generate.js';
import verify from './commands/verify.js';
import submit from './commands/submit.js';
import replay from './commands/replay.js';

const program = new Command();

program
  .name('aurora')
  .description('Aurora ZK Proof CLI Demo')
  .version('1.0.0');

program.command('generate')
  .description('Generate a ZK proof from input data')
  .argument('<data>', 'input data')
  .action(generate);

program.command('verify')
  .description('Verify a ZK proof')
  .argument('<proof>', 'hex-encoded proof')
  .argument('<data>', 'input data')
  .action(verify);

program.command('submit')
  .description('Submit a proof to the compliance registry')
  .argument('<proof>', 'hex-encoded proof')
  .argument('<data>', 'input data')
  .action(submit);

program.command('replay')
  .description('Attempt a replay attack (should fail)')
  .action(replay);

program.parse();
