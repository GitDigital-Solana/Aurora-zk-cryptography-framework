import { useState } from 'react';
import ProofForm from './components/ProofForm';
import ResultBox from './components/ResultBox';

export default function App() {
  const [result, setResult] = useState('');

  return (
    <div style={{ padding: 40, fontFamily: 'sans-serif' }}>
      <h1>Aurora ZK Proof Demo</h1>
      <ProofForm onResult={setResult} />
      <ResultBox result={result} />
    </div>
  );
}
