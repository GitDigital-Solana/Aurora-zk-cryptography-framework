import { useState } from 'react';
import { generateProof, verifyProof } from 'aurora-sdk';

export default function ProofForm({ onResult }: { onResult: (msg: string) => void }) {
  const [data, setData] = useState('');

  const handleGenerate = () => {
    const bytes = new TextEncoder().encode(data);
    const proof = generateProof(bytes, Date.now());
    const valid = verifyProof(proof, bytes);
    onResult(
      `Proof: ${Buffer.from(proof).toString('hex')}\nVerification: ${valid}`
    );
  };

  return (
    <div>
      <textarea
        placeholder="Enter data"
        value={data}
        onChange={(e) => setData(e.target.value)}
        style={{ width: '100%', height: 80 }}
      />
      <button onClick={handleGenerate}>Generate Proof</button>
    </div>
  );
}
