export default function ResultBox({ result }: { result: string }) {
  return (
    <pre style={{ marginTop: 20, padding: 20, background: '#eee', borderRadius: 8 }}>
      {result}
    </pre>
  );
}
